This directory contains test cases for individual source features of LLVM.
It is designed to make sure that the major components of LLVM support all of the
features of LLVM, for very small examples.  Entire programs should not go here.

Regression tests for individual bug fixes should go into the test/Regression dir.

