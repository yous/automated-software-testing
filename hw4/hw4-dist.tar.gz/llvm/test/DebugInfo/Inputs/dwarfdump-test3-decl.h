#include "dwarfdump-test3-decl2.h"

class C {
  explicit C(bool a = false, bool b = false);
};

void do1() {}
