#include "dwarfdump-test4-decl.h"
int d(){a();}
